{
  "code": 0,
  "msg": "",
  "count": "100",
  "data": [{
    "permissionName": "添加用户",
    "url": "/admin/addUser"
  }]
}