{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "username": "水色人生"
    , "realname": "过客"
    , "gender": "男"
    , "phone": "18711111111"
    , "email": "10000@qq.com"
  }]
}