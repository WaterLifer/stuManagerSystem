{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "startTime": "2018年9月"
    , "endTime": "2019年6月"
    , "schoolName": "湖南网络工程职业学院"
    , "schoolJob": "班长"
    , "reterence": "张三"
    , "expComments": "我在学校积极活跃，积极参加学校的各类活动，竞选班上班干部，成功当选班长"
  }]
}