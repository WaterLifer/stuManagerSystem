{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "20200828"
    , "stuName": "张三"
    , "homeworkGrade": "优秀"
    , "homeworkScore": "98"
    , "homeworkStatus": "已交"
    , "homeworkComments": "这个学生表现优秀"
  }]
}