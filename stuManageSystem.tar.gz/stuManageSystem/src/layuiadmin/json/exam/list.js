{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "20200828"
    , "stuName": "张三"
    , "examScore": "0"
    , "examStatus": "缺考"
    , "examComments": "这个学生考试在宿舍睡觉"
  }]
}