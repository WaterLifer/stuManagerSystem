{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "202000001"
    ,"stuName": "张三"
    , "projectName": "某某旅游网"
    , "structureScore": "80"
    , "viewScore": "80"
    , "backboneScore": "80"
    , "standardScore": "80"
    , "beautifulScore": "80"
    , "tellScore": "80"
    , "controlScore": "80"
    , "defenceStatus": "答辩"
    , "defenceComments": "这个学生表现优秀"
  }]
}