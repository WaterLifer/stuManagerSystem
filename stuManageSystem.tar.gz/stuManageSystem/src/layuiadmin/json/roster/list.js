{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "20200828"
    , "stuName": "张三"
    , "rosterStatus": "已到"
    , "rosterComments": "这个学生表现优秀"
  }]
}