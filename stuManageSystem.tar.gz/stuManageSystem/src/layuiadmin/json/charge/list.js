{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "202000001"
    , "stuName": "张三"
    , "chargeCost": "16000"
    , "chargeDate": "2019年6月"
    , "chargeType": "微信"
    , "chargeComments": "一次性缴清"
  }]
}