{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "empCompany": "湖南科创信息技术有限公司"
    , "empDept": "软件开发"
    , "empStation": "java开发工程师"
    , "empSalary": "8000"
    , "empDate": "2020年8月25日"
    , "empRemarks": "我是想就业"
  }]
}