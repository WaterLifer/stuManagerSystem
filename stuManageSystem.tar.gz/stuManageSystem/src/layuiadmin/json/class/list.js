{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "classNo": "J20200827"
    , "className": "Java11班"
    , "classStartDate": "2020年8月27日"
    , "classEndDate": "2023年8月27日"
    , "grade": "S0"
    , "major": "前端"
    , "classComments": "优秀班级"
  }]
}