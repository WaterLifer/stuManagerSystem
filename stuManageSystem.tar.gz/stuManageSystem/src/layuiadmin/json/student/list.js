{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "stuNo": "202000001"
    ,"stuName": "张三"
    ,"stuGender": "男"
    ,"stuMobile": "18711111111"
    ,"stuIDCard": "43252219999999"
    ,"status": "在读"
  }]
}