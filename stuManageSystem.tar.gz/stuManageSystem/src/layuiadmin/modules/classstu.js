/**

 @Name：layuiAdmin 内容系统
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL
    
 */


layui.define(['table', 'form'], function(exports){
  var $ = layui.$
  ,table = layui.table
  ,form = layui.form;

  //文章管理
  table.render({
    elem: '#LAY-app-content-list'
    ,url: layui.setter.base + 'json/student/list.js' //模拟接口
    ,cols: [[
      {field: 'stuNo', width: 160, title: '学号'}
      ,{field: 'stuName', title: '姓名'}
      ,{field: 'stuGender', title: '性别'}
      ,{field: 'stuMobile', title: '手机号码'}
      ,{field: 'stuIDCard', title: '身份证号码'}
      ,{field: 'status', title: '发布状态', templet: '#buttonTpl', minWidth: 80, align: 'center'}
    ]]
    ,page: true
    ,limit: 10
    ,limits: [10, 15, 20, 25, 30]
    ,text: '对不起，加载出现异常！'
  });

  exports('classstu', {})
});